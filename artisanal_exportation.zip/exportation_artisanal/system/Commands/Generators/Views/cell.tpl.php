<@php

namespace {namespace};

use CodeIgniter\View\Cells\Cell;

class {class} extends Cell
{
    //
}
